# Apple 4.3 / 4.2.6 remediation checklist

- [x] Replace web-only navigation with meaningful native functions: local requests, simulation, field checklist
- [x] Keep the official website available as secondary service access
- [x] Explicitly distinguish local drafts from remote client portal submissions
- [x] Mark all plant measurements as simulations; no physical SCADA connection
- [x] Keep v1.0 free, without StoreKit purchases
- [ ] Successful Xcode and physical iPhone tests
- [ ] Verified screenshots of actual Build 7
- [ ] TestFlight beta test evidence and actual user feedback
- [ ] Verify all 9 Apple answers, including overlap with GRID MANAGEMENT PRO and code provenance
- [ ] Confirm website ownership, licenses, third-party dependencies, privacy statements
- [ ] Sign and upload Build 7 to App Store Connect
- [ ] Reply to current Apple Review conversation with evidence and resubmit only after substantial QA
