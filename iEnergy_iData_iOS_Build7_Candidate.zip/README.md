# iEnergy & iData — differentiated native iOS prototype (Build 7 candidate)

This is a new native SwiftUI source project intended to address Apple's 4.3 / 4.2.6 concerns with substantive features, not just a website wrapper:

- Local technical enquiry drafts, persistence, and user-initiated sharing (NOT server submission)
- Interactive PV + BESS power balance simulator (NOT real SCADA)
- Offline commissioning field checklist, persistence, and sharing
- Official website access as an ancillary function

## Build
Requires macOS, Xcode, and XcodeGen. Run `xcodegen generate`, then build `iEnergyiData` for iOS Simulator. GitHub Actions performs the same unsigned simulator build. **No successful Xcode build or on-device QA is claimed yet.**

## Release safety
Build number 7 is a proposal, not an uploaded App Store Connect build. The real Apple Team ID, Bundle ID, signing certificate and provisioning profile must be verified before archiving. Do not upload secrets to the repository. No payments or subscriptions are included.

## Apple review
Test on a physical iPhone; capture a real recording; document TestFlight participants, feedback and fixes. Disclose actual shared code and licensing; explain product differences from GRID MANAGEMENT PRO. Do not submit until functional QA and review answers are complete.
