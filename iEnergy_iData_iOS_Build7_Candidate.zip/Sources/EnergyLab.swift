import SwiftUI

struct PlantSimulator: View {
    @State private var sunlight = 70.0
    @State private var demand = 55.0
    @State private var bessSetpoint = 15.0
    @State private var stateOfCharge = 60.0
    @State private var gridConnected = true
    private let pvCapacity = 70.0
    private let batteryCapacity = 100.0
    private var pv: Double { pvCapacity * sunlight / 100 }
    private var batteryActual: Double {
        if bessSetpoint > 0 && stateOfCharge <= 0 { return 0 }
        if bessSetpoint < 0 && stateOfCharge >= 100 { return 0 }
        return bessSetpoint
    }
    private var balance: Double { pv + batteryActual - demand }
    var body: some View {
        Form {
            Section {
                Label("SIMULATION — NOT LIVE SCADA", systemImage: "info.circle.fill")
                    .foregroundStyle(.orange).font(.headline)
                Text("Educational 70 MW PV / 100 MWh BESS plant. Values are hypothetical and do not connect to any physical equipment.")
                    .font(.footnote)
            }
            Section("Plant status") {
                Toggle("Grid breaker closed", isOn: $gridConnected)
                LabeledContent("PV generation", value: String(format: "%.1f MW", pv))
                LabeledContent("Battery dispatch", value: String(format: "%+.1f MW", batteryActual))
                LabeledContent("Local demand", value: String(format: "%.1f MW", demand))
                LabeledContent(gridConnected ? "Grid export (+) / import (-)" : "Island power imbalance", value: String(format: "%+.1f MW", balance))
                if !gridConnected && abs(balance) > 0.5 { Label("Island imbalance: adjust setpoints", systemImage: "exclamationmark.triangle").foregroundStyle(.orange) }
            }
            Section("Scenario controls") {
                ValueSlider(name: "Solar irradiance", value: $sunlight, range: 0...100, unit: "%")
                ValueSlider(name: "Site demand", value: $demand, range: 0...100, unit: "MW")
                ValueSlider(name: "Battery power (+ discharge)", value: $bessSetpoint, range: -40...40, unit: "MW")
                ValueSlider(name: "Battery state of charge", value: $stateOfCharge, range: 0...100, unit: "%")
                Button("Reset scenario") { sunlight = 70; demand = 55; bessSetpoint = 15; stateOfCharge = 60; gridConnected = true }
            }
            Section("Engineering note") {
                Text("This is a static power-balance exercise. It does not model voltage, reactive power, protection, losses, ramp limits, state-of-charge evolution, or grid-code compliance.")
                    .font(.footnote).foregroundStyle(.secondary)
            }
        }.navigationTitle("Hybrid Energy Lab")
    }
}

struct ValueSlider: View {
    let name: String
    @Binding var value: Double
    let range: ClosedRange<Double>
    let unit: String
    var body: some View {
        VStack(alignment: .leading) {
            HStack { Text(name); Spacer(); Text(String(format: "%.0f %@", value, unit)).monospacedDigit().foregroundStyle(.secondary) }
            Slider(value: $value, in: range)
        }
    }
}
