import SwiftUI

struct FieldChecklist: View {
    private let checks = ["Permit and work authorization checked", "Latest SLD and revision verified", "Equipment identification confirmed", "Protection settings reviewed", "Earthing and bonding inspected", "SCADA signal list reviewed", "Interlocks and control modes verified", "Test records and punch list updated", "Handover documentation reviewed"]
    @AppStorage("ienergy.field.checks.v1") private var stored = ""
    @State private var notes = ""
    private var completed: Set<Int> { Set(stored.split(separator: ",").compactMap { Int($0) }) }
    var body: some View {
        Form {
            Section("Local field inspection") {
                ProgressView(value: Double(completed.count), total: Double(checks.count))
                Text("\(completed.count) of \(checks.count) items marked").font(.caption)
            }
            Section("Commissioning observations") {
                ForEach(checks.indices, id: \.self) { i in
                    Button {
                        var next = completed
                        if next.contains(i) { next.remove(i) } else { next.insert(i) }
                        stored = next.sorted().map(String.init).joined(separator: ",")
                    } label: {
                        HStack {
                            Image(systemName: completed.contains(i) ? "checkmark.circle.fill" : "circle").foregroundStyle(completed.contains(i) ? Color.green : Color.secondary)
                            Text(checks[i]).foregroundStyle(.primary)
                        }
                    }
                }
            }
            Section {
                ShareLink(item: "iEnergy & iData — local field checklist\n" + checks.enumerated().map { (i, name) in "\(completed.contains(i) ? "[x]" : "[ ]") \(name)" }.joined(separator: "\n")) {
                    Label("Share checklist", systemImage: "square.and.arrow.up")
                }
                Button("Clear checks", role: .destructive) { stored = "" }
            }
            Text("Personal checklist only. It is not a signed test protocol or evidence of equipment compliance.")
                .font(.footnote).foregroundStyle(.secondary)
        }.navigationTitle("Field Notes")
    }
}
