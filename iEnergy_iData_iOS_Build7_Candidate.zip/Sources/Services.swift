import SwiftUI
import WebKit

struct ServicesView: View {
    var body: some View {
        List {
            Section("Official platform") {
                Text("Browse the official engineering website and client services. Website login, enquiries and payments are handled by the website, not by the local request drafts.")
                    .font(.footnote).foregroundStyle(.secondary)
                NavigationLink("Open official iEnergy & iData website") { OfficialWebsite() }
                Link("Open website in Safari", destination: URL(string: "https://ienergy-idata.com/")!)
            }
            Section("About this app") {
                Text("iEnergy & iData is a client-oriented workspace for technical enquiries, a hybrid plant learning lab, field notes and access to the official services website.")
                Text("Free in this version. No in-app subscriptions or purchases.")
            }
        }.navigationTitle("Services")
    }
}

struct OfficialWebsite: View {
    var body: some View {
        WebsiteView(url: URL(string: "https://ienergy-idata.com/")!)
            .navigationTitle("Official Website")
            .navigationBarTitleDisplayMode(.inline)
    }
}

struct WebsiteView: UIViewRepresentable {
    let url: URL
    func makeUIView(context: Context) -> WKWebView {
        let web = WKWebView()
        web.allowsBackForwardNavigationGestures = true
        web.load(URLRequest(url: url))
        return web
    }
    func updateUIView(_ uiView: WKWebView, context: Context) {}
}
