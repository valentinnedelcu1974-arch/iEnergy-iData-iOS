import SwiftUI

@main
struct IEnergyApp: App {
    var body: some Scene { WindowGroup { MainTabs() } }
}

enum Brand {
    static let ink = Color(red: 0.05, green: 0.10, blue: 0.19)
    static let mint = Color(red: 0.18, green: 0.76, blue: 0.73)
}

struct MainTabs: View {
    var body: some View {
        TabView {
            NavigationStack { Overview() }.tabItem { Label("Overview", systemImage: "square.grid.2x2.fill") }
            NavigationStack { RequestsView() }.tabItem { Label("My Requests", systemImage: "tray.full.fill") }
            NavigationStack { PlantSimulator() }.tabItem { Label("Energy Lab", systemImage: "waveform.path.ecg") }
            NavigationStack { FieldChecklist() }.tabItem { Label("Field Notes", systemImage: "checklist") }
            NavigationStack { ServicesView() }.tabItem { Label("Services", systemImage: "globe") }
        }.tint(Brand.mint)
    }
}

struct Overview: View {
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                HStack {
                    Image(systemName: "bolt.circle.fill").font(.system(size: 44)).foregroundStyle(Brand.mint)
                    VStack(alignment: .leading) {
                        Text("iEnergy & iData").font(.title2.bold())
                        Text("Energy services & client workspace").font(.subheadline).foregroundStyle(.secondary)
                    }
                }
                Text("Your energy project workspace").font(.largeTitle.bold())
                Text("Organize technical enquiries, explore a simulated hybrid power plant and keep field observations in one place.")
                    .foregroundStyle(.secondary)
                NavigationLink { RequestsView() } label: { FeatureCard(name: "Technical request workspace", detail: "Draft, save and share engineering enquiries", symbol: "doc.text") }
                NavigationLink { PlantSimulator() } label: { FeatureCard(name: "Hybrid Energy Lab", detail: "Interactive PV + BESS dispatch scenarios", symbol: "battery.100percent.bolt") }
                NavigationLink { FieldChecklist() } label: { FeatureCard(name: "Field Notes", detail: "Record commissioning observations offline", symbol: "checklist") }
                NavigationLink { ServicesView() } label: { FeatureCard(name: "Official service portal", detail: "Access iEnergy & iData website", symbol: "globe") }
                Text("All local requests and field notes remain on this device unless you explicitly share them. No live grid equipment is controlled.")
                    .font(.footnote).foregroundStyle(.secondary)
            }.padding(20)
        }.navigationTitle("Overview")
    }
}

struct FeatureCard: View {
    let name: String
    let detail: String
    let symbol: String
    var body: some View {
        HStack(spacing: 14) {
            Image(systemName: symbol).font(.title2).foregroundStyle(Brand.mint).frame(width: 38)
            VStack(alignment: .leading, spacing: 4) {
                Text(name).font(.headline)
                Text(detail).font(.caption).foregroundStyle(.secondary)
            }
            Spacer()
            Image(systemName: "chevron.right").foregroundStyle(.secondary)
        }.padding().background(Brand.ink.opacity(0.07), in: RoundedRectangle(cornerRadius: 16))
    }
}
