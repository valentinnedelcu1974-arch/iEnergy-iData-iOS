# Build 7 preparation status

Target repository: valentinnedelcu1974-arch/iEnergy-iData-iOS only.
Version 1.0, build 7, Bundle ID com.ienergyidata.ios.

Local YAML and privacy plist parsing passed. Xcode compilation and UI tests have NOT run: GitHub integration rejected both create_tree and create_branch with 403 Resource not accessible by integration. No repository changes were applied.

The workflow builds the native Sources folder, generates the existing app icon, runs native UI tests and preserves results. Manual upload_testflight=true reuses the repository's existing API-key and signing-asset configuration. Credentials, profile expiry and actual signing success have not been verified. Build number is fixed at 7 rather than GITHUB_RUN_NUMBER.

Required existing configuration: secret APPSTORE_API_PRIVATE_KEY, secret IENERGY_SIGNING_ASSETS; variables APPSTORE_API_KEY_ID, APPSTORE_ISSUER_ID, APPLE_TEAM_ID. Signing asset JSON keys: p12, password, profile, uuid, name, certificate_sha1. Never commit private keys or signing assets. Confirm profile matches com.ienergyidata.ios and team before upload.

Install project files into the repository. The historical root iEnergyApp.swift is superseded by Sources and excluded from the new project; it may be removed. Preserve the historical Build 6 screenshot workflow as historical evidence only. Run the updated testflight workflow with upload disabled first. Correct any compiler/UI test failures before signed upload. Verify the resulting IPA metadata is 1.0 (7), then confirm processing in App Store Connect and assign the build to the intended TestFlight group. No App Review submission is performed by this workflow.

Review draft is in REVIEW_RESPONSE_DRAFT.md. It requires factual provenance, overlap and physical-device evidence before sending. No monetization, StoreKit products or changes to other apps were introduced.
