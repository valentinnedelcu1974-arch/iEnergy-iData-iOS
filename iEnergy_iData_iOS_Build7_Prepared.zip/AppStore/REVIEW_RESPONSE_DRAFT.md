# App Review response draft — 1.0 (7)

Do not send until CI and physical iPhone testing are complete.

## Guideline 4.3

Thank you for reviewing iEnergy & iData. Build 7 changes the app from website navigation into a native engineering client workspace: offline technical enquiries with local persistence and native sharing; an educational 70 MW PV / 100 MWh BESS static power-balance exercise; and a persistent field checklist with site observations and sharing. Website access is secondary. No login is required for these native features. Saving a draft does not submit it to a backend. The simulator does not control equipment or establish grid-code compliance.

Reviewer steps: My Requests → Create technical enquiry → enter a project and question → Save → relaunch → Share enquiry. Energy Lab → adjust sliders → toggle grid breaker → inspect island imbalance → Reset scenario. Field Notes → mark items → enter observations → relaunch → Share checklist.

This update targets com.ienergyidata.ios only. GRID MANAGEMENT PRO has not been modified. Before sending, complete a factual comparison with its current functionality and any other apps specifically named by Apple. A separate Bundle ID is not evidence of distinct functionality.

## Guideline 4.2.6

The submitted project implements its primary workflows in SwiftUI with Apple system frameworks, including Foundation and WebKit. It does not reference commercial template generators or third-party package dependencies. The native workflows do not require the website to load.

Before sending, confirm the submitting account belongs to the content provider, website ownership and content licensing, and source provenance. Do not claim exclusive authorship or absence of shared code without evidence. Describe AI-assisted implementation accurately if asked.

## Required evidence

- CI build and native UI tests for the submitted commit; physical iPhone testing.
- Real Build 7 screenshots/video and TestFlight processing status.
- Exact current Apple rejection text and answers to its individual questions.
- Accurate privacy disclosure covering native local data and website handling; verified privacy URL and content rights.

Reference: https://developer.apple.com/app-store/review/guidelines/
