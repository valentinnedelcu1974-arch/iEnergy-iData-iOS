import SwiftUI

struct TechnicalRequest: Identifiable, Codable {
    var id: UUID = UUID()
    var created: Date = Date()
    var project: String
    var technology: String
    var question: String
    var priority: String
    var status: String = "Local draft"
}

@MainActor
final class RequestStore: ObservableObject {
    @Published var items: [TechnicalRequest] = [] { didSet { persist() } }
    private let key = "ienergy.requests.v1"
    init() {
        if let data = UserDefaults.standard.data(forKey: key), let saved = try? JSONDecoder().decode([TechnicalRequest].self, from: data) { items = saved }
    }
    private func persist() { if let data = try? JSONEncoder().encode(items) { UserDefaults.standard.set(data, forKey: key) } }
}

struct RequestsView: View {
    @EnvironmentObject private var store: RequestStore
    @State private var showNew = false
    var body: some View {
        List {
            Section {
                Text("Requests are saved locally. They are not submitted to iEnergy & iData until you explicitly share them or use the official website.")
                    .font(.footnote).foregroundStyle(.secondary)
                Button { showNew = true } label: { Label("Create technical enquiry", systemImage: "plus.circle.fill") }
            }
            Section("Local request drafts") {
                if store.items.isEmpty { ContentUnavailableView("No requests yet", systemImage: "tray", description: Text("Create a draft for a technical enquiry.")) }
                ForEach(store.items) { item in
                    VStack(alignment: .leading, spacing: 6) {
                        Text(item.project).font(.headline)
                        Text("\(item.technology) · \(item.priority) · \(item.status)").font(.caption).foregroundStyle(.secondary)
                        Text(item.question).lineLimit(3)
                        ShareLink(item: "iEnergy & iData technical enquiry\nProject: \(item.project)\nTechnology: \(item.technology)\nPriority: \(item.priority)\nQuestion: \(item.question)") { Label("Share enquiry", systemImage: "square.and.arrow.up") }
                    }.padding(.vertical, 5)
                }.onDelete { store.items.remove(atOffsets: $0) }
            }
        }.navigationTitle("My Requests")
        .sheet(isPresented: $showNew) { NewRequestSheet { store.items.insert($0, at: 0) } }
    }
}

struct NewRequestSheet: View {
    @Environment(\.dismiss) private var dismiss
    @State private var project = ""
    @State private var technology = "PV + BESS"
    @State private var priority = "Normal"
    @State private var question = ""
    let onSave: (TechnicalRequest) -> Void
    var body: some View {
        NavigationStack {
            Form {
                TextField("Project or site name", text: $project)
                Picker("Technology", selection: $technology) {
                    ForEach(["PV + BESS", "Grid connection", "Substation", "Wind", "Commissioning", "Other"], id: \.self) { Text($0) }
                }
                Picker("Priority", selection: $priority) {
                    ForEach(["Normal", "High", "Critical"], id: \.self) { Text($0) }
                }
                Section("Technical question") { TextEditor(text: $question).frame(minHeight: 130) }
                Text("Saving creates an offline draft only. No backend transmission or payment is performed.")
                    .font(.footnote).foregroundStyle(.secondary)
            }
            .navigationTitle("New enquiry")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") { onSave(TechnicalRequest(project: project.trimmingCharacters(in: .whitespacesAndNewlines), technology: technology, question: question.trimmingCharacters(in: .whitespacesAndNewlines), priority: priority)); dismiss() }
                        .disabled(project.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || question.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
            }
        }
    }
}
