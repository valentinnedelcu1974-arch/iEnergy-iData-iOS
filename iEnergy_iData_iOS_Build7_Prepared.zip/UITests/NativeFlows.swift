import XCTest

final class NativeFlows: XCTestCase {
    func testDraftPersists() {
        let app = XCUIApplication()
        app.launch()
        app.tabBars.buttons["My Requests"].tap()
        app.buttons["Create technical enquiry"].tap()
        XCTAssertFalse(app.buttons["Save"].isEnabled)
        let name = "QA " + String(UUID().uuidString.prefix(6))
        app.textFields["Project or site name"].tap()
        app.textFields["Project or site name"].typeText(name)
        app.textViews.firstMatch.tap()
        app.textViews.firstMatch.typeText("Review connection drawings")
        app.buttons["Save"].tap()
        XCTAssertTrue(app.staticTexts[name].waitForExistence(timeout: 5))
        app.terminate()
        app.launch()
        app.tabBars.buttons["My Requests"].tap()
        XCTAssertTrue(app.staticTexts[name].waitForExistence(timeout: 5))
    }
    func testSimulation() {
        let app = XCUIApplication()
        app.launch()
        app.tabBars.buttons["Energy Lab"].tap()
        XCTAssertTrue(app.staticTexts["49.0 MW"].exists)
        XCTAssertTrue(app.staticTexts["+9.0 MW"].exists)
        app.switches["Grid breaker closed"].tap()
        XCTAssertTrue(app.staticTexts["Island imbalance: adjust setpoints"].exists)
    }
}
