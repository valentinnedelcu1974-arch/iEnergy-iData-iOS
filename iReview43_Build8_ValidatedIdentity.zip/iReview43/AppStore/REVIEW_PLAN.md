# Apple review remediation — iReview43

## Do not resubmit until
1. Compile and test on physical iPhone running current supported iOS.
2. Verify native features are present in the actual signed binary.
3. Record an authentic screen capture showing launch, native requests, simulator, checklist, portal and theme toggle.
4. Document genuine beta tester feedback, devices and corrections; never invent testing.
5. Audit code/assets against GRID MANAGEMENT PRO and other developer apps; disclose shared elements honestly.
6. Verify ownership of the website, logo and content and identify all third-party SDKs and services.
7. Verify app privacy, age rating, rights, privacy URL, support URL, screenshots from actual binary and reviewer credentials if needed.
8. Answer all nine App Review questions for 4.3/4.2.6 with verified facts.
9. Submit via App Store Connect only after all validations pass.

## Product distinction
GRID MANAGEMENT PRO: grid engineering productivity and technical calculations.
iReview43: client project drafting, offline hybrid energy scenario simulation, field-note tracking and official iEnergy & iData service access. Avoid claiming online sync or live data.

## Monetization
Free download; no IAP, no subscriptions, no ad SDK in this source candidate.

## Apple keys and certificates
Do not store secrets in source or ZIP. Signing requires actual Apple Team ID, appropriate app identifier, certificate/provisioning or managed signing, and secure CI secrets.

## Screenshot guidance
Capture actual app from iPhone or Xcode Simulator; export original device pixel resolution; upload only sizes currently accepted in App Store Connect. Do not fabricate screenshots from mockups.
