# iReview43 — Apple review evidence checklist

Status: development candidate, not an Apple-submitted build.

## Guideline 4.3 / 4.2.6
- Demonstrate original, native request drafting, hybrid energy simulation and commissioning checklist on a physical iPhone.
- Compare actual behavior and source/assets with GRID MANAGEMENT PRO; remove duplicated features before submission.
- Confirm platform/content ownership and all third-party libraries and rights. Do not claim a proprietary feature unless implemented.
- Record physical-device test results, OS version, dates, actual beta feedback and fixes; do not fabricate feedback.
- Confirm whether the iReview43 app is an update of the existing app (must reuse exact Bundle ID) or a new app listing.

## Release blockers
- Run XcodeGen and full Xcode simulator build on macOS.
- Run TestFlight and physical-device smoke tests (launch, dark/light, forms, offline persistence, share sheet, simulator boundary values, website load and error handling).
- Review privacy policy and App Privacy for native storage and website behavior.
- Generate genuine App Store screenshots from the final build.
- Set up distribution signing only in secure Apple/GitHub environments; never commit signing keys or certificates.
- Obtain Apple Review decision before claiming Ready for Distribution.
