# iReview43 Build 8 source candidate

- Updated build number to 8.
- Added native delete control for locally saved technical requests.
- Free; no IAP.
- Not yet compiled on macOS or submitted to Apple.
- Bundle ID is provisional; verify existing App Store Connect identifier before signing.
- Review 4.3 and 4.2.6 requires evidence of functional differentiation, ownership, real device testing, and third-party components.
