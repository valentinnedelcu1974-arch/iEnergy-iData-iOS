# iReview43 CI and TestFlight release checklist

1. Confirm the exact existing App Store Connect Bundle ID before any replacement. The project currently uses a provisional ID.
2. Upload this project into a dedicated branch or new repository; do not overwrite the live app without a backup.
3. Run GitHub Actions iReview43 iOS Build; inspect logs and correct any Xcode errors.
4. For TestFlight, configure signing in a separate protected workflow with Apple credentials stored in GitHub Actions Secrets. Never commit .p8, .p12 or .mobileprovision.
5. Upload a signed IPA via App Store Connect API/Transporter, verify processing, and install on a physical iPhone.
6. Verify request persistence/deletion, energy simulator bounds, offline handling, portal navigation, and Day/Night settings.
7. Capture real App Store screenshots from the tested build, and audit third-party code, privacy and rights.
8. Answer Apple's Guideline 4.3 and 4.2.6 questions with actual test evidence.
9. Submit for review only after all checks pass.

Status: CI source package only; no Xcode build, signing, TestFlight upload or Apple submission completed.
