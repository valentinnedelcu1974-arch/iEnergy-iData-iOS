# iReview43 Release Gate — 2026-11-10

## Verified locally
- Swift parser: all five sources passed (`swiftc -frontend -parse`).
- Icon: 1024×1024 RGB PNG; asset catalog manifest references icon.png.
- XcodeGen project and GitHub Actions YAML present and structurally readable.
- Source contains native requests, offline energy lab, field checklist, and appearance selector.

## NOT verified — do not claim success
- Xcode compilation, linking, simulator execution, physical iPhone testing.
- Client portal login, service availability, accessibility, website integration and App Privacy accuracy.
- Apple Developer team signing, certificate validity, provisioning, TestFlight upload.
- Apple review submission or approval.

## Migration decisions required
1. To replace the existing App Store Connect app, use its **existing** Bundle ID, not the proposed new one in project.yml. Confirm existing record's editable app name and app icon.
2. For a new App Store record, use a unique Bundle ID and separate signing profile. Avoid deleting the prior record until migration is verified.
3. Do not reuse credentials by copying them into source control; provision encrypted CI secrets with least privilege.
4. Keep the application free and do not claim 'no data collected' until the website, portal, and embedded web content are audited.
5. Document actual beta testers, dates, devices, feedback, changes, shared code/SDKs, and ownership for Guidelines 4.3 and 4.2.6.
