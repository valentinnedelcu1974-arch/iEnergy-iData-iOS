# iReview43 — release readiness (2026-11-10)

## Verified locally
- Build source files present; project.yml configured for iOS 17+ and build number 8.
- EnergyMath model compiles and its executable tests pass using Linux Swift compiler.
- ZIP package structure and icon asset validated.

## Required before Apple submission
1. Run GitHub Actions macOS `iReview43 iOS Build` and resolve all compiler errors.
2. Confirm actual Bundle ID of existing App Store Connect record; provisional `com.ienergyidata.ireview43` is NOT suitable for an update to a different Bundle ID.
3. Verify signing team, certificate, provisioning profile and export compliance; never commit signing keys to public GitHub.
4. Test on a physical iPhone and record real feature navigation, persistence, delete controls, theme, web portal, offline behavior.
5. Capture real App Store screenshots from the running build.
6. Audit website cookies, third-party SDKs, privacy labels, content rights and age rating.
7. Document real differences from GRID MANAGEMENT PRO and explain source-code/asset reuse for Apple 4.3/4.2.6.
8. Submit only after TestFlight distribution and review metadata validation.

## Scope
No changes to website, existing apps or Apple account have been made. No Apple review request has been sent.
