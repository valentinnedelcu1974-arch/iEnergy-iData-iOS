from pathlib import Path
from PIL import Image
import json, subprocess, sys
root=Path(__file__).resolve().parents[1]
files=sorted((root/'Sources').glob('*.swift'))
assert len(files)>=5, 'Swift source files missing'
check=subprocess.run(['swiftc','-frontend','-parse',*[str(p) for p in files]],capture_output=True,text=True)
if check.returncode: print(check.stderr); sys.exit(check.returncode)
icon=Image.open(root/'Assets.xcassets/AppIcon.appiconset/icon.png')
assert icon.size==(1024,1024) and icon.mode in ('RGB','RGBA')
assert json.loads((root/'Assets.xcassets/AppIcon.appiconset/Contents.json').read_text())['images'][0]['filename']=='icon.png'
for f in ('project.yml','.github/workflows/ios-build.yml','README.md'):
 assert (root/f).is_file(), f
print('PASS: Swift syntax, app icon dimensions, required files')
