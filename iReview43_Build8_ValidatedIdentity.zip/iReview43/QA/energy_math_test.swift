import Foundation
@main struct Tests {
 static func main() {
  let a = EnergyBalance.calculate(pvCapacityMW:70, irradiancePercent:75, demandMW:48, requestedBatteryMW:12, socPercent:65)
  precondition(abs(a.pvMW - 52.5) < 0.00001)
  precondition(abs(a.gridMW - 16.5) < 0.00001)
  let b = EnergyBalance.calculate(pvCapacityMW:70, irradiancePercent:100, demandMW:30, requestedBatteryMW:10, socPercent:0)
  precondition(b.batteryMW == 0)
  let c = EnergyBalance.calculate(pvCapacityMW:70, irradiancePercent:100, demandMW:30, requestedBatteryMW:-10, socPercent:100)
  precondition(c.batteryMW == 0)
  print("Energy math tests PASS")
 }
}
