# iReview43 — Native iOS rebuild

A standalone, SwiftUI-first iPhone application for iEnergy & iData's energy engineering audience.

## Modules
- Animated branded launch and day/night theme
- Native technical request drafts, saved locally, manually shareable
- Native offline PV+BESS illustrative power balance lab
- Offline field commissioning checklist
- Official iEnergy & iData web portal (read-only integration; no website changes)

## Build
Install XcodeGen on macOS, run `xcodegen generate`, then build the `iReview43` scheme. GitHub Actions builds an unsigned simulator target. App Store distribution requires signing configuration and an Apple Developer account.

## Release caution
This is **source code only**, not a signed .ipa or approved App Store build. App Review 4.3 / 4.2.6 require genuine differentiation, evidence of ownership, beta testing, and a verified component inventory. A new name alone does not resolve rejection. Verify all App Privacy declarations against the actual web content and SDK behavior.

## App Store migration
A display-name change and new binary may be possible for the existing App Store Connect app if its Bundle ID remains unchanged. This project uses a **new proposed Bundle ID** `com.ienergyidata.ireview43` for a clean standalone identity. Apple does not allow changing an existing app's Bundle ID after app record creation. To reuse the existing App Store Connect record, replace the bundle identifier in `project.yml` with the *actual* registered bundle identifier and ensure the existing app record can be renamed. Do not revoke or copy private keys into GitHub. Reuse signing infrastructure only after validating team, app identifier and provisioning profiles.
