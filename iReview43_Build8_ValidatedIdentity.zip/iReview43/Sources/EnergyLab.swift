import SwiftUI

struct EnergyLabView: View {
    @State private var irradiance = 75.0
    @State private var demand = 48.0
    @State private var batteryPower = 12.0
    @State private var stateOfCharge = 65.0
    private var solarMW: Double { EnergyBalance.calculate(pvCapacityMW: 70, irradiancePercent: irradiance, demandMW: demand, requestedBatteryMW: batteryPower, socPercent: stateOfCharge).pvMW }
    private var batteryMW: Double { EnergyBalance.calculate(pvCapacityMW: 70, irradiancePercent: irradiance, demandMW: demand, requestedBatteryMW: batteryPower, socPercent: stateOfCharge).batteryMW }
    private var gridMW: Double { solarMW + batteryMW - demand }
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                Text("PV 70 MW + BESS 100 MWh").font(.title2.bold())
                Text("Interactive, offline engineering illustration").foregroundStyle(.secondary)
                HStack(spacing: 8) {
                    metric("PV", String(format: "%.1f MW", solarMW), "sun.max.fill")
                    metric("BESS", String(format: "%.1f MW", batteryMW), "battery.75percent")
                    metric("Grid", String(format: "%+.1f MW", gridMW), "bolt.fill")
                }
                GroupBox("Solar irradiance — \(Int(irradiance))%") { Slider(value: $irradiance, in: 0...100) }
                GroupBox("Demand — \(Int(demand)) MW") { Slider(value: $demand, in: 0...100) }
                GroupBox("BESS discharge (+) / charge (−) — \(Int(batteryPower)) MW") { Slider(value: $batteryPower, in: -50...50, step: 1) }
                GroupBox("Battery state of charge — \(Int(stateOfCharge))%") { Slider(value: $stateOfCharge, in: 0...100, step: 1) }
                GroupBox("Power balance") {
                    VStack(alignment: .leading, spacing: 6) {
                        Text(gridMW >= 0 ? "Export to grid (illustrative)" : "Import from grid (illustrative)")
                        ProgressView(value: min(abs(gridMW) / 100, 1))
                        Text(String(format: "%.1f MW", abs(gridMW))).font(.title.bold())
                    }.frame(maxWidth: .infinity, alignment: .leading)
                }
                Text("Model simplifications: no inverter clipping, losses, efficiency, grid-code limits, SOC time integration or actual dispatch control. Never use these values for operating equipment.")
                    .font(.footnote).foregroundStyle(.secondary)
            }.padding()
        }.navigationTitle("Hybrid Energy Lab")
    }
    private func metric(_ title: String, _ value: String, _ symbol: String) -> some View {
        VStack(spacing: 8) {
            Image(systemName: symbol).foregroundStyle(.blue)
            Text(title).font(.caption)
            Text(value).font(.subheadline.bold()).minimumScaleFactor(0.65).lineLimit(1)
        }.frame(maxWidth: .infinity).padding(12).background(.regularMaterial, in: RoundedRectangle(cornerRadius: 14))
    }
}
