import Foundation

/// Deterministic, offline illustration. Not suitable for dispatch or protection settings.
struct EnergyBalance {
    static func calculate(pvCapacityMW: Double, irradiancePercent: Double, demandMW: Double, requestedBatteryMW: Double, socPercent: Double) -> (pvMW: Double, batteryMW: Double, gridMW: Double) {
        let pv = max(0, pvCapacityMW) * min(100, max(0, irradiancePercent)) / 100
        let soc = min(100, max(0, socPercent))
        let battery = (soc <= 0 && requestedBatteryMW > 0) || (soc >= 100 && requestedBatteryMW < 0) ? 0 : requestedBatteryMW
        return (pv, battery, pv + battery - demandMW)
    }
}
