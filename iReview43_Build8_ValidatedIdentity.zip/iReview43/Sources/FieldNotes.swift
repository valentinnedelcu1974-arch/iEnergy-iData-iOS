import SwiftUI

struct FieldNotesView: View {
    private let tasks = ["Permit to work verified", "Approved drawings available", "Equipment identification checked", "Earthing and bonding checked", "Protection settings reviewed", "SCADA point-to-point checked", "Interlocks verified", "Commissioning test records reviewed", "Handover package checked"]
    @AppStorage("fieldNotesChecked") private var saved = ""
    private var checked: Set<Int> { Set(saved.split(separator: ",").compactMap { Int($0) }) }
    var body: some View {
        List {
            Section {
                ProgressView(value: Double(checked.count), total: Double(tasks.count))
                Text("\(checked.count) of \(tasks.count) completed").font(.caption)
            }
            Section("Commissioning checklist") {
                ForEach(tasks.indices, id: \.self) { index in
                    Button {
                        var updated = checked
                        if updated.contains(index) { updated.remove(index) } else { updated.insert(index) }
                        saved = updated.sorted().map(String.init).joined(separator: ",")
                    } label: {
                        Label(tasks[index], systemImage: checked.contains(index) ? "checkmark.circle.fill" : "circle")
                            .foregroundStyle(.primary)
                    }
                }
            }
            Section {
                ShareLink("Share checklist status", item: tasks.enumerated().map { "\(checked.contains($0.offset) ? "[x]" : "[ ]") \($0.element)" }.joined(separator: "\n"))
                Button("Reset checklist", role: .destructive) { saved = "" }
            }
            Section { Text("A planning aid only. It does not replace signed commissioning procedures, test records or site authorization.").font(.footnote) }
        }.navigationTitle("Field Notes")
    }
}
