import SwiftUI
import WebKit

struct OfficialPortalView: View {
    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Image(systemName: "lock.shield").foregroundStyle(.blue)
                Text("Official website — ienergy-idata.com").font(.caption)
                Spacer()
                Link(destination: URL(string: "https://ienergy-idata.com/")!) { Image(systemName: "safari") }
            }.padding(10)
            PortalWebView(url: URL(string: "https://ienergy-idata.com/")!)
        }.navigationTitle("Official Services")
    }
}

struct PortalWebView: UIViewRepresentable {
    let url: URL
    func makeUIView(context: Context) -> WKWebView {
        let configuration = WKWebViewConfiguration()
        let view = WKWebView(frame: .zero, configuration: configuration)
        view.allowsBackForwardNavigationGestures = true
        view.load(URLRequest(url: url))
        return view
    }
    func updateUIView(_ view: WKWebView, context: Context) {}
}

struct SettingsView: View {
    @AppStorage("localRequests") private var localRequests = Data()
    @AppStorage("appearance") private var appearance = "system"
    var body: some View {
        Form {
            Section("Appearance") {
                Picker("Theme", selection: $appearance) {
                    Text("System").tag("system")
                    Text("Day").tag("light")
                    Text("Night").tag("dark")
                }
            }
            Section("Platform") {
                NavigationLink("Official website and client portal") { OfficialPortalView() }
                Link("Open official website in Safari", destination: URL(string: "https://ienergy-idata.com/")!)
            }
            Section("Privacy") {
                Text("Native project drafts and checklist state are stored on this device using local app preferences. The official website may apply its own privacy and cookie policies.")
                Link("Website privacy information", destination: URL(string: "https://ienergy-idata.com/")!)
            }
            Section("Local data controls") {
                Button("Delete locally saved technical requests", role: .destructive) {
                    localRequests = Data()
                }
                Text("Deletes drafts on this device, not data submitted through the website.")
                    .font(.footnote).foregroundStyle(.secondary)
            }
            Section("About") {
                LabeledContent("Application", value: "iReview43")
                LabeledContent("Version", value: "1.0 (8) — development candidate")
                Text("Free application. No subscriptions or in-app purchases in this build.")
            }
        }.navigationTitle("Settings")
    }
}
