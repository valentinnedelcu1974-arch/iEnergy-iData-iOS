import SwiftUI

@main
struct iReview43App: App {
    @AppStorage("appearance") private var appearance = "system"
    var body: some Scene {
        WindowGroup {
            RootView()
                .preferredColorScheme(appearance == "dark" ? .dark : appearance == "light" ? .light : nil)
        }
    }
}

struct RootView: View {
    @State private var showSplash = !ProcessInfo.processInfo.arguments.contains("--ui-testing")
    var body: some View {
        ZStack {
            TabView {
                NavigationStack { HomeView() }.tabItem { Label("Home", systemImage: "house.fill") }
                NavigationStack { RequestsView() }.tabItem { Label("Projects", systemImage: "folder.fill") }
                NavigationStack { EnergyLabView() }.tabItem { Label("Energy Lab", systemImage: "bolt.fill") }
                NavigationStack { FieldNotesView() }.tabItem { Label("Field Notes", systemImage: "checklist") }
                NavigationStack { SettingsView() }.tabItem { Label("More", systemImage: "ellipsis.circle.fill") }
            }
            .tint(.blue)
            if showSplash {
                SplashView()
                    .transition(.opacity.combined(with: .scale(scale: 1.05)))
                    .zIndex(1)
            }
        }
        .task {
            try? await Task.sleep(for: .seconds(1.6))
            withAnimation(.easeInOut(duration: 0.5)) { showSplash = false }
        }
    }
}

struct SplashView: View {
    @State private var pulse = false
    var body: some View {
        ZStack {
            LinearGradient(colors: [Color(red: 0.03, green: 0.08, blue: 0.20), .blue, .red.opacity(0.7)], startPoint: .topLeading, endPoint: .bottomTrailing).ignoresSafeArea()
            VStack(spacing: 20) {
                Image(systemName: "checkmark.seal.fill")
                    .font(.system(size: 96, weight: .bold))
                    .symbolRenderingMode(.palette)
                    .foregroundStyle(.white, .blue)
                    .shadow(color: .cyan, radius: 24)
                    .scaleEffect(pulse ? 1.07 : 0.92)
                Text("iReview43").font(.system(size: 40, weight: .black, design: .rounded)).foregroundStyle(.white)
                Text("Energy • Projects • Review").foregroundStyle(.white.opacity(0.85))
            }
        }
        .onAppear { withAnimation(.easeInOut(duration: 0.75).repeatForever(autoreverses: true)) { pulse = true } }
        .accessibilityLabel("iReview43 opening screen")
    }
}

struct FeatureCard: View {
    let title: String
    let subtitle: String
    let symbol: String
    var body: some View {
        HStack(spacing: 14) {
            Image(systemName: symbol).font(.title2).frame(width: 42, height: 42).foregroundStyle(.blue)
                .background(.blue.opacity(0.10), in: RoundedRectangle(cornerRadius: 12))
            VStack(alignment: .leading, spacing: 4) {
                Text(title).font(.headline)
                Text(subtitle).font(.caption).foregroundStyle(.secondary)
            }
            Spacer()
            Image(systemName: "chevron.right").foregroundStyle(.secondary)
        }.padding(14).background(.regularMaterial, in: RoundedRectangle(cornerRadius: 18))
    }
}

struct HomeView: View {
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                ZStack(alignment: .bottomLeading) {
                    RoundedRectangle(cornerRadius: 25).fill(LinearGradient(colors: [.blue, .indigo, .red.opacity(0.7)], startPoint: .topLeading, endPoint: .bottomTrailing))
                    VStack(alignment: .leading, spacing: 10) {
                        Image(systemName: "bolt.shield.fill").font(.largeTitle)
                        Text("Energy Engineering").font(.largeTitle.bold())
                        Text("iReview43 • powered by iEnergy & iData")
                        Text("Project workspace, energy simulations and field checklists")
                            .font(.subheadline)
                    }.foregroundStyle(.white).padding(24)
                }.frame(height: 210)
                Text("Your workspace").font(.title2.bold())
                NavigationLink { RequestsView() } label: { FeatureCard(title: "Technical Requests", subtitle: "Draft, save and share project requests", symbol: "doc.text.fill") }
                NavigationLink { EnergyLabView() } label: { FeatureCard(title: "Hybrid Energy Lab", subtitle: "Native PV and BESS simulation", symbol: "battery.100percent.bolt") }
                NavigationLink { FieldNotesView() } label: { FeatureCard(title: "Field Notes", subtitle: "Offline commissioning checklist", symbol: "checkmark.seal.fill") }
                NavigationLink { OfficialPortalView() } label: { FeatureCard(title: "Official iEnergy & iData", subtitle: "Website and client services", symbol: "globe.europe.africa.fill") }
                Text("Simulated data is illustrative and not a live grid measurement.")
                    .font(.footnote).foregroundStyle(.secondary)
            }.padding()
        }.navigationTitle("iReview43")
    }
}
