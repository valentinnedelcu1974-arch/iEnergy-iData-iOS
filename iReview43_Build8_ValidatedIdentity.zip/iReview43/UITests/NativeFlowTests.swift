import XCTest

final class NativeFlowTests: XCTestCase {
    func testNativeFlows() throws {
        let app = XCUIApplication()
        app.launchArguments = ["--ui-testing", "-localRequests", "", "-fieldNotesChecked", "", "-appearance", "system"]
        app.launch()
        XCTAssertTrue(app.tabBars.buttons["Projects"].waitForExistence(timeout: 10))
        app.tabBars.buttons["Projects"].tap()
        app.textFields["Project or site"].tap()
        app.textFields["Project or site"].typeText("Review demo project")
        let details = app.descendants(matching: .any).matching(identifier: "request.details").firstMatch
        XCTAssertTrue(details.exists)
        details.tap()
        details.typeText("Check PV and battery integration")
        app.buttons["Done"].tap()
        app.buttons["Save request on this iPhone"].tap()
        XCTAssertTrue(app.staticTexts["Review demo project"].exists)
        attach(app, "Projects")
        app.terminate()
        app.launchArguments = ["--ui-testing"]
        app.launch()
        XCTAssertTrue(app.tabBars.buttons["Projects"].waitForExistence(timeout: 10))
        app.tabBars.buttons["Projects"].tap()
        XCTAssertTrue(app.staticTexts["Review demo project"].exists)
        app.tabBars.buttons["Energy Lab"].tap()
        XCTAssertEqual(app.sliders.count, 4)
        app.sliders.element(boundBy: 0).adjust(toNormalizedSliderPosition: 0)
        XCTAssertTrue(app.staticTexts["0.0 MW"].exists)
        attach(app, "Energy-Lab")
        app.tabBars.buttons["Field Notes"].tap()
        app.buttons["Permit to work verified"].tap()
        XCTAssertTrue(app.staticTexts["1 of 9 completed"].exists)
        attach(app, "Field-Notes")
        app.buttons["Reset checklist"].tap()
        XCTAssertTrue(app.staticTexts["0 of 9 completed"].exists)
        app.tabBars.buttons["More"].tap()
        XCTAssertTrue(app.staticTexts["Free application. No subscriptions or in-app purchases in this build."].exists)
        app.buttons["Delete locally saved technical requests"].tap()
        app.tabBars.buttons["Projects"].tap()
        XCTAssertTrue(app.staticTexts["No saved requests yet"].exists)
        app.tabBars.buttons["Home"].tap()
        attach(app, "Home")
    }
    private func attach(_ app: XCUIApplication, _ name: String) {
        let attachment = XCTAttachment(screenshot: app.screenshot())
        attachment.name = name
        attachment.lifetime = .keepAlways
        add(attachment)
    }
}
