# iReview43 — Build 9 candidate, 12 November 2026

Status: SOURCE PREPARED; NOT COMPILED, NOT SIGNED, NOT UPLOADED, NOT SUBMITTED.

App record retained: 6831976341. Bundle ID retained: com.ienergyidata.ios. Separate branch: fix/ireview43-apple-review, based on work/ireview43-build8. Main is now used for Mercury Auto (a separate Bundle ID); do not merge over main or use its deployment workflow.

## Implemented changes

The Energy Lab tab now opens a native 24-hour dispatch study, not the previous static power-balance slider. The deterministic one-hour model integrates battery energy with one-way charge/discharge efficiency; enforces 0–100% SOC, AC power rating and grid export cap; reports grid import/export and PV curtailment; compares storage against a no-storage baseline; and provides an accessible hourly table, stored-energy chart, local save/restore and CSV file export. Inputs include PV rating, constant demand, battery capacity/rating, initial SOC, export cap and efficiency.

This adds substantive functionality but does not, by itself, prove compliance with 4.3. Generic project requests and checklist features remain and still require comparison against iStar and GRID MANAGEMENT PRO.

The model uses synthetic PV and constant demand. It is not a live forecast, grid-code study, protection calculation or operating control. The app explicitly explains these limits. Baseline comparisons disclose initial stored-energy use and do not claim economic savings.

## Nine Apple questions: evidence and remaining work

1. **Purpose:** Existing local enquiries, checklist and portal remain. Build 9 adds an offline scenario calculation that shows how PV, demand, export constraints and storage affect 24-hour energy exchange. Verify this workflow on the final binary before sending an answer.
2. **Audience:** Engineers and project coordinators screening illustrative PV/BESS scenarios and preparing technical enquiries. This is intended positioning, not measured demand.
3. **Market gap:** Demonstrate the complete workflow with screenshots and a recording. Do not claim that no other app offers it. Collect actual user evidence of why this combination is useful and compare related apps before asserting sufficient differentiation.
4. **Beta testing:** Prior Build 8 documentation records simulator/UI checks; those do not validate Build 9. New mathematical tests cover hourly AC balance, stored-energy balance, full/empty/zero-capacity storage, power limits, export cap, disabled storage, nonfinite inputs and CSV row count. They have NOT run here: no local Swift/Xcode toolchain, and remote writes/CI are blocked. No physical-device or external beta feedback is evidenced. Request actual tester device/iOS, flows tried, failures and feedback; do not fabricate feedback or a production fix history.
5. **Related apps:** Standalone runtime: no dependence on another installed app. Account-wide scope comparison remains open, particularly iStar and GRID MANAGEMENT PRO. Do not describe this as unrelated to all other apps without checking them.
6. **Consolidation:** Functionality could technically be integrated into another energy app. Separate packaging must be justified by a verified audience/workflow comparison. Retain the existing app record; do not create a duplicate to avoid rejection.
7. **Shared account code/assets:** Legacy wrapper code and lightning branding are present in repository history. Build 8 native sources were extracted from the validated source archive, and generic flows remain. Inventory exact reused source/assets against the other apps and disclose findings. Do not claim zero sharing.
8. **Third-party reuse:** Candidate project declares no external package dependencies. Native code imports Apple frameworks (SwiftUI, Foundation, UIKit, WebKit, Charts and UniformTypeIdentifiers); code is AI-assisted. This is not a complete provenance audit of legacy icon or remote website content. Verify ownership/licences before certification.
9. **Content provider:** Platform is ienergy-idata.com, associated with the account holder in prior project documentation. Establish the precise ownership/permission relationship and whether any client supplied concept, branding or content. Do not invent an entity or ownership declaration.

## Validation and delivery blockers observed this session

- Shell git push: failed; no GitHub credentials available to shell.
- Connected GitHub create_branch: HTTP 403, Resource not accessible by integration. No remote branch or CI run created by this session.
- App Store Connect opened the signed-in iReview43 record, but Distribution content remained loading after one reload. No Apple fields or review messages changed.
- No signing secrets, certificates or other apps modified.
- Build 9 is unvalidated source. Do not submit the former rejected binary unchanged or send this internal status as a compliance assertion.

## Concrete next steps

Upload this isolated source branch using authorized GitHub browser access or restore connector write access; run the included macOS validation workflow. Correct any compile/UI failures. Audit related apps and content provenance, then prepare final metadata and nine factual answers. Complete signed upload and processing, test on a real iPhone through TestFlight, record actual feedback and fix any defects. Only then send the verified answers/new candidate to Apple, following the review team's chosen route. Apple alone decides approval.
