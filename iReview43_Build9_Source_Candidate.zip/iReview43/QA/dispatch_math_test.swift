import Foundation

@main
struct DispatchMathTests {
    static func main() {
        func near(_ a: Double, _ b: Double) { precondition(abs(a - b) < 0.000001, "Energy balance mismatch") }
        for capacity in [0.0, 1, 100, 400] {
            for initial in [0.0, 50, 100] {
                var s = DispatchScenario()
                s.batteryMWh = capacity
                s.initialSOC = initial
                let r = DispatchStudy.run(s)
                precondition(r.hours.count == 24)
                var previous = capacity * initial / 100
                for row in r.hours {
                    precondition(row.stored >= 0 && row.stored <= capacity)
                    precondition(abs(row.battery) <= s.batteryMW + 0.000001)
                    precondition(row.grid <= s.exportLimitMW + 0.000001)
                    near(row.pv + row.battery - row.demand - row.curtailed, row.grid)
                    let delta = row.battery >= 0 ? -row.battery / s.efficiency : -row.battery * s.efficiency
                    near(row.stored, previous + delta)
                    previous = row.stored
                }
                let baseline = DispatchStudy.run(s, storageEnabled: false)
                precondition(baseline.hours.allSatisfy { $0.battery == 0 })
                precondition(r.csv.split(separator: "\n").count == 25)
            }
        }
        var empty = DispatchScenario()
        empty.pvMW = 0; empty.initialSOC = 0
        let r = DispatchStudy.run(empty)
        near(r.importedMWh, 24 * empty.demandMW)
        near(r.exportedMWh, 0)
        near(r.finalStoredMWh, 0)
        var full = DispatchScenario()
        full.demandMW = 0; full.initialSOC = 100; full.exportLimitMW = 0
        let f = DispatchStudy.run(full)
        precondition(f.hours.allSatisfy { $0.battery == 0 && $0.grid == 0 })
        near(f.finalStoredMWh, full.batteryMWh)
        var invalid = DispatchScenario()
        invalid.pvMW = .nan; invalid.batteryMW = .infinity; invalid.initialSOC = -.infinity
        precondition(DispatchStudy.run(invalid).hours.allSatisfy { $0.grid.isFinite && $0.stored.isFinite })
        print("PASS: 24-hour energy conservation, SOC, rating, export cap, zero capacity, full/empty battery, CSV and nonfinite inputs")
    }
}
