# iReview43 Build 9 candidate

Existing App Store identity: 6831976341 / com.ienergyidata.ios. Free native SwiftUI app for iOS 17+. Source prepared on 12 November 2026; not yet compiled, signed or uploaded.

The Energy Lab tab now provides a deterministic 24-hour PV/BESS study with SOC integration, efficiency, AC power limit, export cap, baseline comparison, hourly results, CSV export and local scenario save/restore. Existing enquiries, checklist and website access remain.

Generate with XcodeGen from this directory. Run `xcodebuild -project iReview43.xcodeproj -scheme iReview43 -destination 'platform=iOS Simulator,name=iPhone 17 Pro' CODE_SIGNING_ALLOWED=NO test` using an available simulator name. The root `.github/workflows/ireview43-validation.yml` selects macOS Intel/Xcode 26.3, checks source/model behaviour, compiles, runs UI tests and retains diagnostics. It does not load signing secrets or upload a binary.

Do not deploy using main: the repository's main branch is currently used for Mercury Auto, with a different Bundle ID. Review `AppStore/BUILD9_REVIEW_STATUS.md` before any submission. Earlier QA files are historical Build 8 notes, not evidence of Build 9 validation.
