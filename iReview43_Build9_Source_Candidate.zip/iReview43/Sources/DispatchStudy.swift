import Foundation

/// One-hour AC energy balance. Synthetic profiles, no connection to equipment.
struct DispatchScenario: Codable, Equatable {
    var name = "PV and storage study"
    var pvMW = 70.0
    var demandMW = 25.0
    var batteryMWh = 100.0
    var batteryMW = 25.0
    var initialSOC = 50.0
    var exportLimitMW = 20.0
    var efficiency = 0.95 // one-way charge and discharge efficiency
}

struct DispatchHour: Identifiable {
    let hour: Int
    let pv: Double
    let demand: Double
    let battery: Double // positive AC discharge; negative AC charge
    let grid: Double // positive export; negative import
    let curtailed: Double
    let stored: Double
    var id: Int { hour }
}

struct DispatchResult {
    let hours: [DispatchHour]
    var importedMWh: Double { hours.reduce(0) { $0 + max(0, -$1.grid) } }
    var exportedMWh: Double { hours.reduce(0) { $0 + max(0, $1.grid) } }
    var curtailedMWh: Double { hours.reduce(0) { $0 + $1.curtailed } }
    var finalStoredMWh: Double { hours.last?.stored ?? 0 }
    var csv: String {
        let header = "hour,pv_MW,demand_MW,battery_MW,grid_MW,curtailed_MW,stored_MWh"
        return ([header] + hours.map { row in
            ([Double(row.hour), row.pv, row.demand, row.battery, row.grid, row.curtailed, row.stored].map {
                String(format: "%.6f", locale: Locale(identifier: "en_US_POSIX"), $0)
            }).joined(separator: ",")
        }).joined(separator: "\n")
    }
}

struct DispatchStudy {
    static func run(_ input: DispatchScenario, storageEnabled: Bool = true) -> DispatchResult {
        func finite(_ v: Double, _ fallback: Double = 0) -> Double { v.isFinite ? v : fallback }
        let capacity = max(0, finite(input.batteryMWh))
        let rating = storageEnabled ? max(0, finite(input.batteryMW)) : 0
        let efficiency = min(1, max(0.01, finite(input.efficiency, 1)))
        let limit = max(0, finite(input.exportLimitMW))
        var stored = capacity * min(100, max(0, finite(input.initialSOC))) / 100
        var hours: [DispatchHour] = []
        for hour in 0..<24 {
            // Fixed illustrative clear-day curve: zero at 06:00 and 18:00.
            let sun = max(0, sin(Double(hour - 6) * .pi / 12))
            let pv = max(0, finite(input.pvMW)) * sun
            let demand = max(0, finite(input.demandMW))
            let surplus = pv - demand
            var battery = 0.0
            if surplus > 0 {
                let charge = min(surplus, rating, max(0, capacity - stored) / efficiency)
                stored += charge * efficiency
                battery = -charge
            } else {
                let discharge = min(-surplus, rating, stored * efficiency)
                stored -= discharge / efficiency
                battery = discharge
            }
            stored = min(capacity, max(0, stored))
            let beforeCurtailment = surplus + battery
            let curtailed = max(0, beforeCurtailment - limit)
            hours.append(DispatchHour(hour: hour, pv: pv, demand: demand, battery: battery,
                                      grid: beforeCurtailment - curtailed, curtailed: curtailed, stored: stored))
        }
        return DispatchResult(hours: hours)
    }
}
