import SwiftUI
import Charts
import UniformTypeIdentifiers

struct StudyCSV: FileDocument {
    static var readableContentTypes: [UTType] { [.commaSeparatedText] }
    var text: String
    init(text: String) { self.text = text }
    init(configuration: ReadConfiguration) throws {
        text = String(decoding: configuration.file.regularFileContents ?? Data(), as: UTF8.self)
    }
    func fileWrapper(configuration: WriteConfiguration) throws -> FileWrapper {
        FileWrapper(regularFileWithContents: Data(text.utf8))
    }
}

struct DispatchStudyView: View {
    @AppStorage("dispatchStudy.scenario.v1") private var saved = ""
    @State private var scenario = DispatchScenario()
    @State private var exporting = false
    @State private var message: String?
    private var result: DispatchResult { DispatchStudy.run(scenario) }
    private var baseline: DispatchResult { DispatchStudy.run(scenario, storageEnabled: false) }
    var body: some View {
        Form {
            Section("Offline 24-hour study") {
                Text("Synthetic clear-day PV profile and constant demand. Battery charges from PV surplus and discharges to meet demand. Grid charging is disabled.")
                    .font(.footnote)
                TextField("Study name", text: $scenario.name)
                control("PV capacity", value: $scenario.pvMW, range: 0...200, unit: "MW")
                control("Demand", value: $scenario.demandMW, range: 0...100, unit: "MW")
                control("Battery capacity", value: $scenario.batteryMWh, range: 0...400, unit: "MWh")
                control("Battery AC rating", value: $scenario.batteryMW, range: 0...100, unit: "MW")
                control("Initial SOC", value: $scenario.initialSOC, range: 0...100, unit: "%")
                control("Export limit", value: $scenario.exportLimitMW, range: 0...200, unit: "MW")
                VStack(alignment: .leading) {
                    Text("One-way efficiency: \(Int((scenario.efficiency * 100).rounded()))%")
                    Slider(value: $scenario.efficiency, in: 0.70...1, step: 0.01)
                        .accessibilityLabel("One-way efficiency")
                }
            }
            Section("With storage / Without storage") {
                comparison("Grid import", result.importedMWh, baseline.importedMWh)
                comparison("Grid export", result.exportedMWh, baseline.exportedMWh)
                comparison("PV curtailment", result.curtailedMWh, baseline.curtailedMWh)
                Text(String(format: "Final stored energy: %.1f MWh", result.finalStoredMWh))
                Text("The two cases start with the same PV and demand. The storage case can consume its initial energy; final SOC is not forced to equal initial SOC. This is not an economic comparison.")
                    .font(.caption).foregroundStyle(.secondary)
            }
            Section("Stored energy across 24 hours") {
                Chart(result.hours) { row in
                    LineMark(x: .value("Hour", row.hour + 1), y: .value("MWh", row.stored))
                }
                .chartXScale(domain: 0...24)
                .chartYScale(domain: 0...max(1, scenario.batteryMWh))
                .frame(height: 180)
                .accessibilityLabel("Stored energy. Read exact hourly values in the table below.")
            }
            Section("Study files") {
                Button("Save study on this iPhone") {
                    do {
                        saved = String(decoding: try JSONEncoder().encode(scenario), as: UTF8.self)
                        message = "Study saved on this iPhone."
                    } catch { message = "The study could not be saved." }
                }
                Button("Restore saved study") {
                    guard let data = saved.data(using: .utf8), let value = try? JSONDecoder().decode(DispatchScenario.self, from: data) else {
                        message = "No valid saved study is available."; return
                    }
                    scenario = value
                    message = "Saved study restored."
                }.disabled(saved.isEmpty)
                Button("Export hourly CSV") { exporting = true }
                Button("Reset inputs") { scenario = DispatchScenario() }
                if let message { Text(message).font(.caption).accessibilityIdentifier("study.message") }
            }
            Section("Hourly results • positive grid = export") {
                ForEach(result.hours) { row in
                    VStack(alignment: .leading, spacing: 4) {
                        Text(String(format: "%02d:00–%02d:00", row.hour, row.hour + 1)).font(.headline)
                        Text(String(format: "PV %.1f • Demand %.1f • BESS %+.1f MW", row.pv, row.demand, row.battery))
                        Text(String(format: "Grid %+.1f MW • Curtailed %.1f MW • Stored %.1f MWh", row.grid, row.curtailed, row.stored))
                    }.font(.caption)
                }
            }
            Section("Assumptions") {
                Text("One-hour steps; PV is AC output on a fixed synthetic sine curve; demand is constant. SOC is integrated using one-way battery efficiency and constrained to 0–100%. Battery AC rating and export cap are enforced. No weather forecasts, price data, degradation, reactive power, thermal limits, protection or grid-code assessment. Results are educational and do not authorize equipment operation.")
                    .font(.footnote)
            }
        }
        .navigationTitle("Dispatch Study")
        .fileExporter(isPresented: $exporting, document: StudyCSV(text: result.csv), contentType: .commaSeparatedText, defaultFilename: "iReview43-24h-study") { outcome in
            switch outcome {
            case .success: message = "CSV exported."
            case .failure: message = "CSV export did not complete. Try again."
            }
        }
    }
    private func control(_ name: String, value: Binding<Double>, range: ClosedRange<Double>, unit: String) -> some View {
        VStack(alignment: .leading) {
            Text("\(name): \(Int(value.wrappedValue)) \(unit)")
            Slider(value: value, in: range, step: 1).accessibilityLabel(name)
        }
    }
    private func comparison(_ name: String, _ storage: Double, _ noStorage: Double) -> some View {
        VStack(alignment: .leading) {
            Text(name).font(.headline)
            Text(String(format: "%.1f / %.1f MWh", storage, noStorage)).monospacedDigit()
        }
    }
}
