import SwiftUI

struct OfficialPortalView: View {
    var body: some View {
        List {
            Section("iEnergy & iData services") {
                Text("The project workspace and dispatch study work offline. The service website opens separately in your browser.")
                Link("Open iEnergy & iData website", destination: URL(string: "https://ienergy-idata.com/")!)
            }
            Section("Before opening the website") {
                Text("The website has its own privacy practices. Enquiries and data entered there are handled by the website. This app does not automatically submit your drafts, checklist or saved study.")
            }
        }.navigationTitle("Official Services")
    }
}

struct LocalPrivacyView: View {
    var body: some View {
        List {
            Section("Data on this device") {
                Text("Project drafts, checklist state, appearance and one saved dispatch scenario are kept in the app's local preferences. The app contains no account service, advertising SDK, analytics SDK or automatic upload of these records.")
            }
            Section("Sharing and exports") {
                Text("Sharing a draft or checklist and exporting a CSV happen only when you choose those actions. The destination you select, such as Files or a sharing app, handles the exported copy. Deleting local records does not delete exported copies. Device backups may include app data according to your iPhone settings.")
            }
            Section("External website") {
                Text("The official website opens in your browser. Data you enter there follows the website's policies. The app does not embed the website or send it your local records.")
            }
            Section("Deleting records") {
                Text("Use Settings → Local data controls to delete requests, checklist state or the saved study. Removing the app removes its local app data; exported copies and device backups are managed separately.")
            }
        }.navigationTitle("App Privacy")
    }
}

struct SettingsView: View {
    @AppStorage("localRequests") private var localRequests = Data()
    @AppStorage("appearance") private var appearance = "system"
    @AppStorage("dispatchStudy.scenario.v1") private var savedStudy = ""
    @AppStorage("fieldNotesChecked") private var checklist = ""
    private var version: String {
        let info = Bundle.main.infoDictionary ?? [:]
        return "\(info["CFBundleShortVersionString"] as? String ?? "1.0") (\(info["CFBundleVersion"] as? String ?? "9"))"
    }
    var body: some View {
        Form {
            Section("Appearance") {
                Picker("Theme", selection: $appearance) {
                    Text("System").tag("system")
                    Text("Day").tag("light")
                    Text("Night").tag("dark")
                }
            }
            Section("Platform") {
                NavigationLink("Official website and client portal") { OfficialPortalView() }
            }
            Section("Privacy") {
                NavigationLink("App privacy and local data") { LocalPrivacyView() }
                Text("Local records stay in the app until you explicitly share or export them.")
            }
            Section("Local data controls") {
                Button("Delete locally saved technical requests", role: .destructive) { localRequests = Data() }
                Button("Delete saved dispatch study", role: .destructive) { savedStudy = "" }
                Button("Reset saved checklist", role: .destructive) { checklist = "" }
                Text("These controls affect this app's records on this device. Exported copies and website submissions are managed separately.")
                    .font(.footnote)
            }
            Section("About") {
                LabeledContent("Application", value: "iReview43")
                LabeledContent("Version", value: version)
                Text("Free application. No subscriptions or in-app purchases in this build.")
            }
        }.navigationTitle("Settings")
    }
}
