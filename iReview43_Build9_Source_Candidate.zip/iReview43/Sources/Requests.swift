import SwiftUI

struct TechnicalRequest: Codable, Identifiable {
    var id = UUID()
    var project: String
    var technology: String
    var details: String
    var created = Date()
}

struct RequestsView: View {
    @AppStorage("localRequests") private var stored = Data()
    @State private var project = ""
    @FocusState private var editing: Bool
    @State private var technology = "PV / BESS"
    @State private var details = ""
    private var requests: [TechnicalRequest] { (try? JSONDecoder().decode([TechnicalRequest].self, from: stored)) ?? [] }
    private var exportText: String {
        requests.map { "Project: \($0.project)\nTechnology: \($0.technology)\nDetails: \($0.details)" }.joined(separator: "\n\n---\n\n")
    }
    var body: some View {
        Form {
            Section("Create a technical request") {
                TextField("Project or site", text: $project).accessibilityIdentifier("request.project").focused($editing)
                Picker("Technology", selection: $technology) {
                    ForEach(["PV / BESS", "HV / MV Substation", "Wind", "Grid Connection", "Commissioning", "Other"], id: \.self) { Text($0) }
                }
                TextField("Describe the request", text: $details, axis: .vertical).lineLimit(3...7).accessibilityIdentifier("request.details").focused($editing)
                Button("Save request on this iPhone") {
                    var items = requests
                    items.insert(TechnicalRequest(project: project.trimmingCharacters(in: .whitespacesAndNewlines), technology: technology, details: details), at: 0)
                    if let encoded = try? JSONEncoder().encode(items) { stored = encoded }
                    project = ""; details = ""
                }.disabled(project.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || details.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
            }
            Section("Saved locally") {
                if requests.isEmpty { Text("No saved requests yet").foregroundStyle(.secondary) }
                ForEach(requests) { item in
                    VStack(alignment: .leading, spacing: 4) {
                        Text(item.project).font(.headline)
                        Text(item.technology).font(.caption).foregroundStyle(.blue)
                        Text(item.details).font(.subheadline)
                    }.padding(.vertical, 5)
                }
                .onDelete { indices in
                    var items = requests
                    items.remove(atOffsets: indices)
                    if let encoded = try? JSONEncoder().encode(items) { stored = encoded }
                }
                if !requests.isEmpty { ShareLink("Share request summary", item: exportText) }
            }
            Section { Text("Requests remain on this device until you choose to share them. They are not automatically sent to the website or a consultant.").font(.footnote) }
        }.navigationTitle("Technical Requests")
        .toolbar { ToolbarItemGroup(placement: .keyboard) { Spacer(); Button("Done") { editing = false } } }
    }
}
